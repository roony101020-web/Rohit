import { 
  UserProfile, 
  NewsItem, 
  EventItem, 
  GalleryItem, 
  SiteConfig, 
  DEFAULT_CONFIG 
} from '../types';

// NOTE: In a real production environment, this file would import Firebase functions
// and interact with Firestore. For this "Single File" runnable demo, we use 
// LocalStorage to simulate a backend so the app works immediately for the user.

const STORAGE_KEYS = {
  CONFIG: 'sbv_config',
  NEWS: 'sbv_news',
  EVENTS: 'sbv_events',
  GALLERY: 'sbv_gallery',
  USERS: 'sbv_users',
  CURRENT_USER: 'sbv_current_user'
};

// --- Helper to simulate network delay ---
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const db = {
  // --- Auth Simulation ---
  async login(email: string, pass: string): Promise<UserProfile> {
    await delay(500);
    
    // Hardcoded Dev Access
    if (email === 'rohit@sbv.com' && pass === 'dev-master') {
      const devUser: UserProfile = {
        uid: 'dev-001',
        email,
        displayName: 'Rohit (Dev)',
        role: 'dev'
      };
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(devUser));
      return devUser;
    }

    // Check simulated users
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    const user = users.find((u: any) => u.email === email && u.password === pass);

    if (user) {
        // Strip password
        const profile: UserProfile = { 
            uid: user.uid, 
            email: user.email, 
            role: user.role, 
            displayName: user.displayName 
        };
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(profile));
        return profile;
    }

    throw new Error("Invalid credentials");
  },

  async register(email: string, pass: string, name: string): Promise<UserProfile> {
    await delay(500);
    const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
    
    if (users.find((u: any) => u.email === email)) {
      throw new Error("User already exists");
    }

    const newUser = {
      uid: Date.now().toString(),
      email,
      password: pass, // Storing plain text just for this LocalStorage demo
      displayName: name,
      role: 'pending' as const
    };

    users.push(newUser);
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    
    // Auto-login for demo flow, but role is pending
    const profile = { uid: newUser.uid, email: newUser.email, role: newUser.role, displayName: newUser.displayName };
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(profile));
    return profile;
  },

  async logout() {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  },

  getCurrentUser(): UserProfile | null {
    const u = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return u ? JSON.parse(u) : null;
  },

  async getUsers(): Promise<UserProfile[]> {
     // Only for dev
     const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
     return users.map((u: any) => ({ uid: u.uid, email: u.email, role: u.role, displayName: u.displayName }));
  },

  async updateUserRole(uid: string, newRole: string) {
      const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
      const idx = users.findIndex((u: any) => u.uid === uid);
      if (idx !== -1) {
          users[idx].role = newRole;
          localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      }
  },

  // --- Data ---
  async getConfig(): Promise<SiteConfig> {
    const c = localStorage.getItem(STORAGE_KEYS.CONFIG);
    return c ? JSON.parse(c) : DEFAULT_CONFIG;
  },

  async updateConfig(config: SiteConfig) {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
  },

  async getNews(): Promise<NewsItem[]> {
    const d = localStorage.getItem(STORAGE_KEYS.NEWS);
    if (!d) {
        // Seed initial news
        const initial: NewsItem[] = [
            { id: '1', title: 'Annual Sports Day Announced', date: '2023-10-25', content: 'Join us for a day of athletics.', active: true },
            { id: '2', title: 'Science Exhibition Winners', date: '2023-10-20', content: 'Congratulations to Class X-B.', active: true },
        ];
        localStorage.setItem(STORAGE_KEYS.NEWS, JSON.stringify(initial));
        return initial;
    }
    return JSON.parse(d);
  },

  async saveNews(news: NewsItem[]) {
      localStorage.setItem(STORAGE_KEYS.NEWS, JSON.stringify(news));
  },

  async getEvents(): Promise<EventItem[]> {
    const d = localStorage.getItem(STORAGE_KEYS.EVENTS);
    return d ? JSON.parse(d) : [];
  },

  async saveEvents(events: EventItem[]) {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  },

  async getGallery(): Promise<GalleryItem[]> {
      const d = localStorage.getItem(STORAGE_KEYS.GALLERY);
      if (!d) {
          // Seed
          const initial: GalleryItem[] = [
              { id: '1', title: 'Campus View', category: 'Campus', url: 'https://picsum.photos/800/600?random=1' },
              { id: '2', title: 'Library', category: 'Facilities', url: 'https://picsum.photos/800/600?random=2' },
              { id: '3', title: 'Lab', category: 'Academics', url: 'https://picsum.photos/800/600?random=3' }
          ];
          localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(initial));
          return initial;
      }
      return JSON.parse(d);
  },

  async saveGallery(items: GalleryItem[]) {
      localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(items));
  }
};